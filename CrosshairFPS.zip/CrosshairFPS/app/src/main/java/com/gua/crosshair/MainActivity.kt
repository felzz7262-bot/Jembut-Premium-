package com.gua.crosshair

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var sp: SharedPreferences
    private lateinit var preview: CrosshairView
    private lateinit var btn: TextView
    private lateinit var pill: TextView
    private val chips = ArrayList<TextView>()
    private val dots = ArrayList<View>()
    private var d = 1f
    private var on = false

    private val bg = Color.parseColor("#0D0F14")
    private val card = Color.parseColor("#171A22")
    private val accent = Color.parseColor("#7C5CFF")
    private val accent2 = Color.parseColor("#00D1FF")
    private val dim = Color.parseColor("#8A90A2")

    private val models = arrayOf(
        "Dot", "Plus", "Plus Gap", "Circle", "Circle Dot", "X",
        "T-Shape", "Square", "Gap Dot", "Chevron", "Diamond", "Ring Plus"
    )
    private val colors = intArrayOf(
        Color.parseColor("#FF3B3B"), Color.parseColor("#00E5A0"), Color.parseColor("#00D1FF"),
        Color.parseColor("#FFD60A"), Color.parseColor("#FF4DD8"), Color.WHITE,
        Color.parseColor("#FF8800"), Color.parseColor("#3D7BFF"),
        Color.parseColor("#B388FF"), Color.BLACK
    )

    private fun dp(v: Int) = (v * d).toInt()

    private fun shape(c: Int, r: Int, stroke: Int = 0, sw: Int = 1) = GradientDrawable().apply {
        setColor(c); cornerRadius = r * d
        if (stroke != 0) setStroke(dp(sw), stroke)
    }

    private fun grad(a: Int, b: Int, r: Int) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(a, b)).apply { cornerRadius = r * d }

    private fun tv(t: String, sz: Float, c: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(c)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun lpm(top: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun section(title: String, build: LinearLayout.() -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(card, 20, Color.parseColor("#232735"))
            setPadding(dp(16), dp(14), dp(16), dp(16))
            addView(tv(title.uppercase(), 11f, dim, true).apply { letterSpacing = 0.12f; setPadding(0, 0, 0, dp(10)) })
            build()
        }

    private fun applyAll() {
        preview.model = sp.getInt("model", 0)
        preview.color = sp.getInt("color", Color.RED)
        preview.size = sp.getInt("size", 40)
        preview.thick = sp.getInt("thick", 4)
        preview.opacity = sp.getInt("opacity", 100)
        preview.invalidate()
        if (OverlayService.running) startForegroundService(Intent(this, OverlayService::class.java))
    }

    private fun styleChips() {
        val sel = sp.getInt("model", 0)
        chips.forEachIndexed { i, c ->
            if (i == sel) { c.background = grad(accent, accent2, 18); c.setTextColor(Color.WHITE) }
            else { c.background = shape(Color.parseColor("#20243A"), 18); c.setTextColor(dim) }
        }
    }

    private fun styleDots() {
        val sel = sp.getInt("color", colors[0])
        dots.forEachIndexed { i, v ->
            val g = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(colors[i])
                if (colors[i] == sel) setStroke(dp(3), Color.parseColor("#7C5CFF")) else setStroke(dp(1), Color.parseColor("#33FFFFFF"))
            }
            v.background = g
        }
    }

    private fun updateBtn() {
        if (on) {
            btn.text = "STOP OVERLAY"; btn.background = grad(Color.parseColor("#FF3B5C"), Color.parseColor("#FF7A45"), 18)
            pill.text = "● AKTIF"; pill.setTextColor(Color.parseColor("#00E5A0"))
        } else {
            btn.text = "START OVERLAY"; btn.background = grad(accent, accent2, 18)
            pill.text = "● MATI"; pill.setTextColor(dim)
        }
    }

    private fun slider(p: LinearLayout, name: String, key: String, mn: Int, mx: Int, def: Int, unit: String) {
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val label = tv(name, 14f, Color.WHITE).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }
        val value = tv("${sp.getInt(key, def)}$unit", 14f, accent2, true)
        head.addView(label); head.addView(value)
        p.addView(head, lpm(8))
        val sb = SeekBar(this).apply {
            max = mx - mn
            progress = sp.getInt(key, def) - mn
            progressTintList = ColorStateList.valueOf(accent)
            thumbTintList = ColorStateList.valueOf(accent2)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    value.text = "${v + mn}$unit"
                    if (u) { sp.edit().putInt(key, v + mn).apply(); applyAll() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        p.addView(sb, lpm(2))
    }

    private fun toggle(p: LinearLayout, name: String, sub: String, key: String, def: Boolean) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addView(tv(name, 15f, Color.WHITE, true))
            addView(tv(sub, 12f, dim))
        }
        val sw = Switch(this).apply {
            isChecked = sp.getBoolean(key, def)
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(accent2, Color.parseColor("#6B7083"))
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.parseColor("#557C5CFF"), Color.parseColor("#2A2E3F"))
            )
            setOnCheckedChangeListener { _, c -> sp.edit().putBoolean(key, c).apply(); applyAll() }
        }
        row.addView(col); row.addView(sw)
        p.addView(row, lpm(12))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = getSharedPreferences("cfg", MODE_PRIVATE)
        d = resources.displayMetrics.density
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); addView(root) }
        setContentView(scroll)

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = grad(Color.parseColor("#4B2FD6"), Color.parseColor("#0A8FC9"), 24)
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        val topRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        topRow.addView(tv("Crosshair Pro", 24f, Color.WHITE, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        pill = tv("● MATI", 12f, dim, true).apply {
            background = shape(Color.parseColor("#CC0D0F14"), 20)
            setPadding(dp(12), dp(5), dp(12), dp(5))
        }
        topRow.addView(pill)
        header.addView(topRow)
        header.addView(tv("Crosshair, FPS counter, dan layar halus", 13f, Color.parseColor("#D0D6FF")).apply { setPadding(0, dp(4), 0, 0) })
        root.addView(header, lpm())

        // Preview
        preview = CrosshairView(this)
        val pv = FrameLayout(this).apply {
            background = shape(Color.parseColor("#10131A"), 20, Color.parseColor("#232735"))
            addView(preview, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            addView(tv("PREVIEW", 10f, dim, true).apply { setPadding(dp(14), dp(10), 0, 0) })
        }
        root.addView(pv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(250)).apply { topMargin = dp(14) })

        // Model
        root.addView(section("Model crosshair") {
            val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            models.forEachIndexed { i, m ->
                val c = tv(m, 13f, dim, true).apply {
                    setPadding(dp(16), dp(9), dp(16), dp(9))
                    setOnClickListener { sp.edit().putInt("model", i).apply(); styleChips(); applyAll() }
                }
                chips.add(c)
                row.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) })
            }
            addView(HorizontalScrollView(this@MainActivity).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        }, lpm(14))

        // Warna
        root.addView(section("Warna") {
            val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            colors.forEachIndexed { i, c ->
                val v = View(this@MainActivity).apply {
                    setOnClickListener { sp.edit().putInt("color", c).apply(); styleDots(); applyAll() }
                }
                dots.add(v)
                row.addView(v, LinearLayout.LayoutParams(dp(38), dp(38)).apply { rightMargin = dp(10) })
            }
            addView(HorizontalScrollView(this@MainActivity).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        }, lpm(14))

        // Ukuran
        root.addView(section("Tampilan") {
            slider(this, "Ukuran", "size", 10, 120, 40, "")
            slider(this, "Ketebalan", "thick", 1, 12, 4, "")
            slider(this, "Transparansi", "opacity", 10, 100, 100, "%")
        }, lpm(14))

        // Fitur
        root.addView(section("Fitur") {
            toggle(this, "Tampilkan FPS", "Counter di pojok kiri atas layar", "fps", true)
            toggle(this, "Layar halus", "Minta refresh rate tertinggi layar (90/120Hz)", "smooth", true)
            toggle(this, "Layar tetap nyala", "Layar nggak mati sendiri pas overlay aktif", "keepon", true)
        }, lpm(14))

        // Tombol
        btn = tv("START OVERLAY", 16f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(18))
            setOnClickListener {
                if (on) {
                    stopService(Intent(this@MainActivity, OverlayService::class.java)); on = false
                } else if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(context, "Aktifin izin 'Tampil di atas aplikasi lain' dulu", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    startForegroundService(Intent(this@MainActivity, OverlayService::class.java)); on = true
                }
                updateBtn()
            }
        }
        root.addView(btn, lpm(18))

        styleChips(); styleDots(); applyAll(); updateBtn()
    }

    override fun onResume() {
        super.onResume()
        on = OverlayService.running
        updateBtn()
    }
}
