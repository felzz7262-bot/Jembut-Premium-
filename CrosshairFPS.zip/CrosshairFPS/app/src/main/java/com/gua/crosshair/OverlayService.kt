package com.gua.crosshair

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.IBinder
import android.view.Choreographer
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    companion object { var running = false }

    private lateinit var wm: WindowManager
    private var cross: CrosshairView? = null
    private var fpsTv: TextView? = null
    private var frames = 0
    private var last = 0L

    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            if (last == 0L) last = t
            frames++
            if (t - last >= 1_000_000_000L) {
                fpsTv?.text = "$frames FPS"
                frames = 0
                last = t
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ch = "overlay"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Overlay", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Crosshair Pro aktif")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(1, n)
        if (!running) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            running = true
            Choreographer.getInstance().postFrameCallback(cb)
        }
        apply()
        return START_STICKY
    }

    private fun maxRate(): Float {
        var best = 0f
        try {
            val dm = getSystemService(DisplayManager::class.java)
            val disp = dm.getDisplay(Display.DEFAULT_DISPLAY)
            for (m in disp.supportedModes) {
                if (m.refreshRate > best) best = m.refreshRate
            }
        } catch (e: Exception) {
            best = 0f
        }
        return best
    }

    private fun lp(w: Int, h: Int, g: Int, rate: Float = 0f, keepOn: Boolean = false): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (keepOn) flags = flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        val params = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
        params.gravity = g
        if (rate > 0f) params.preferredRefreshRate = rate
        return params
    }

    private fun apply() {
        val sp = getSharedPreferences("cfg", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        val sizeVal = sp.getInt("size", 40)
        val dim = ((sizeVal * 2 + 30) * d).toInt()
        val rate = if (sp.getBoolean("smooth", true)) maxRate() else 0f
        val keepOn = sp.getBoolean("keepon", true)

        var cv = cross
        if (cv == null) {
            cv = CrosshairView(this)
            cross = cv
            wm.addView(cv, lp(dim, dim, Gravity.CENTER, rate, keepOn))
        }
        cv.model = sp.getInt("model", 0)
        cv.color = sp.getInt("color", Color.RED)
        cv.size = sizeVal
        cv.thick = sp.getInt("thick", 4)
        cv.opacity = sp.getInt("opacity", 100)
        cv.invalidate()
        wm.updateViewLayout(cv, lp(dim, dim, Gravity.CENTER, rate, keepOn))

        if (sp.getBoolean("fps", true)) {
            var tv = fpsTv
            if (tv == null) {
                tv = TextView(this)
                tv.text = "-- FPS"
                tv.setTextColor(Color.parseColor("#00E5A0"))
                tv.textSize = 13f
                tv.typeface = android.graphics.Typeface.DEFAULT_BOLD
                val bgShape = GradientDrawable()
                bgShape.setColor(Color.parseColor("#B30D0F14"))
                bgShape.cornerRadius = 20f * d
                bgShape.setStroke((1 * d).toInt(), Color.parseColor("#3300E5A0"))
                tv.background = bgShape
                tv.setPadding((12 * d).toInt(), (5 * d).toInt(), (12 * d).toInt(), (5 * d).toInt())
                fpsTv = tv
                val l = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
                l.x = (24 * d).toInt()
                l.y = (8 * d).toInt()
                wm.addView(tv, l)
            }
        } else {
            val old = fpsTv
            if (old != null) wm.removeView(old)
            fpsTv = null
        }
    }

    override fun onDestroy() {
        Choreographer.getInstance().removeFrameCallback(cb)
        val c1 = cross
        if (c1 != null) wm.removeView(c1)
        val c2 = fpsTv
        if (c2 != null) wm.removeView(c2)
        cross = null; fpsTv = null
        running = false
        super.onDestroy()
    }
}
